{\rtf1\ansi\ansicpg1252\cocoartf1265
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 Kang Wang \
USC-ID: 1093294783\
E-mail: kangwang@usc.edu\
\
Structure of Program\
class tsp\{\
class Node\{\}\
class Edge\{\}\
class State\{\}\
\
function getSPG()\{\} // function return shortest path graph and output files\
function getTSP()\{\} // function return tsp path and log files\
\
main function()\{\}\
\}\
\
Instruction of compile and execute\
1. unzip HW2.zip and remember the folder path\
2. open cmd and access the folder path(if you are Mac user, open terminal)\
3. input \'93javac tsp.java\'94\
4. input \'93java tsp -t 1 -i map1.txt -op output1_path.txt -ol output1_tlog.txt\'94 \
    input \'93java tsp -t 2 -i map2.txt -op output2_path.txt -ol output2_tlog.txt\'94}